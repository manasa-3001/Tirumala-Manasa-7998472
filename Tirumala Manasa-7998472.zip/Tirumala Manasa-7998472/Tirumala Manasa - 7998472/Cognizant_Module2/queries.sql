-- Show all users

SELECT * FROM Users;

-- Show all events

SELECT * FROM Events;

-- Show registrations

SELECT * FROM Registrations;

-- Show feedback

SELECT * FROM Feedback;

-- Upcoming events

SELECT *
FROM Events
WHERE status='Upcoming';

-- User event details

SELECT u.full_name,
       e.title
FROM Users u
JOIN Registrations r
ON u.user_id=r.user_id
JOIN Events e
ON r.event_id=e.event_id;