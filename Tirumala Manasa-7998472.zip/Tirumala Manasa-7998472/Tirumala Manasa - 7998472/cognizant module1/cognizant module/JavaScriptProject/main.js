// 1. Basics

console.log("Welcome to the Community Portal");

window.onload=function(){
alert("Page Fully Loaded");
}

// 2. Data Types

const portalName="Community Event Portal";
const eventDate="2026-05-27";

let seats=50;

console.log(`${portalName} Event Date: ${eventDate}`);

// 3. Event Array

const events=[

{
name:"Music Festival",
category:"Music",
date:"2026-06-01",
seats:20
},

{
name:"Baking Workshop",
category:"Workshop",
date:"2026-06-05",
seats:15
},

{
name:"Sports Meet",
category:"Sports",
date:"2026-06-10",
seats:0
}

];

// 4. Class and Prototype

class Event{

constructor(name,category,seats){

this.name=name;
this.category=category;
this.seats=seats;

}

}

Event.prototype.checkAvailability=function(){

return this.seats>0
?
"Seats Available"
:
"Full";

};

// 5. Display Events

const container=
document.querySelector("#eventContainer");

function displayEvents(list){

container.innerHTML="";

list.forEach((event,index)=>{

if(event.seats<=0){

return;

}

const card=
document.createElement("div");

card.className="eventCard";

card.innerHTML=`

<h3>${event.name}</h3>

<p>Category: ${event.category}</p>

<p>Seats: ${event.seats}</p>

<button onclick="registerUser(${index})">

Register

</button>

`;

container.appendChild(card);

});

}

displayEvents(events);

// 6. Register User

function registerUser(index){

try{

if(events[index].seats<=0){

throw "No Seats Available";

}

events[index].seats--;

alert("Registration Successful");

displayEvents(events);

}
catch(error){

alert(error);

}

}

// 7. Filter Events

document
.querySelector("#categoryFilter")
.onchange=function(){

const value=this.value;

const filtered=
value==="All"
?
events
:
events.filter(
e=>e.category===value
);

displayEvents(filtered);

};

// 8. Search Events

document
.querySelector("#search")
.addEventListener(
"keydown",
function(){

const search=
this.value.toLowerCase();

const filtered=
events.filter(
e=>
e.name.toLowerCase()
.includes(search)
);

displayEvents(filtered);

}
);

// 9. Form Handling

document
.querySelector("#registrationForm")
.addEventListener(
"submit",
function(event){

event.preventDefault();

const form=event.target;

const name=form.elements["name"].value;

const email=form.elements["email"].value;

const selectedEvent=
form.elements["event"].value;

if(name==="" || email===""){

document
.querySelector("#message")
.innerHTML=
"Please Fill All Fields";

return;

}

document
.querySelector("#message")
.innerHTML=
"Submitting Registration...";

// 10. Fetch API

setTimeout(()=>{

fetch(
"https://jsonplaceholder.typicode.com/posts",
{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

name,
email,
selectedEvent

})

}

)

.then(response=>response.json())

.then(data=>{

document
.querySelector("#message")
.innerHTML=
"Registration Successful";

console.log(data);

})

.catch(error=>{

document
.querySelector("#message")
.innerHTML=
"Registration Failed";

console.log(error);

});

},2000);

}
);

// 11. jQuery

$("#registerBtn").click(function(){

$(".eventCard").fadeOut(500).fadeIn(500);

});

// 12. Modern JS

const cloneEvents=[...events];

console.log(cloneEvents);

// 13. Object.entries

events.forEach(event=>{

console.log(
Object.entries(event)
);

});

// 14. Benefit of React/Vue

console.log(
"Frameworks like React improve component reusability and UI performance."
);