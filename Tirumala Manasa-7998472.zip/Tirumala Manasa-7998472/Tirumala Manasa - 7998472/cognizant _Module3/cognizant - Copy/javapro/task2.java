import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double firstNumber = scanner.nextDouble();

        System.out.print("Enter the second number: ");
        double secondNumber = scanner.nextDouble();

        System.out.println("Choose an operation:");
        System.out.println("1. Addition (+)");
        System.out.println("2. Subtraction (-)");
        System.out.println("3. Multiplication (*)");
        System.out.println("4. Division (/)");
        System.out.print("Enter your choice (1-4): ");
        int choice = scanner.nextInt();

        double result;
        switch (choice) {
            case 1:
                result = firstNumber + secondNumber;
                System.out.println("Result: " + firstNumber + " + " + secondNumber + " = " + result);
                break;
            case 2:
                result = firstNumber - secondNumber;
                System.out.println("Result: " + firstNumber + " - " + secondNumber + " = " + result);
                break;
            case 3:
                result = firstNumber * secondNumber;
                System.out.println("Result: " + firstNumber + " * " + secondNumber + " = " + result);
                break;
            case 4:
                if (secondNumber == 0) {
                    System.out.println("Error: Division by zero is not allowed.");
                } else {
                    result = firstNumber / secondNumber;
                    System.out.println("Result: " + firstNumber + " / " + secondNumber + " = " + result);
                }
                break;
            default:
                System.out.println("Invalid choice. Please run the program again and select 1-4.");
                break;
        }

        scanner.close();
    }
}
