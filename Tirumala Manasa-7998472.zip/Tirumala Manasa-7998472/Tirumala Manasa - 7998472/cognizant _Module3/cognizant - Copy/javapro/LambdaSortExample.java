import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaSortExample {
    public static void main(String[] args) {

        // Create a List of strings
        List<String> fruits = new ArrayList<>();
        fruits.add("Banana");
        fruits.add("Apple");
        fruits.add("Mango");
        fruits.add("Orange");

        // Sort the list using a lambda expression
        Collections.sort(fruits, (s1, s2) -> s1.compareTo(s2));

        // Display the sorted list
        System.out.println("Sorted List:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }
    }
}