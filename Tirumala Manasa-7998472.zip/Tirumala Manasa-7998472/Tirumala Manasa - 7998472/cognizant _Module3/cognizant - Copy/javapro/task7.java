public class task7 {
    public static void main(String[] args) {
        double originalDouble = 12.78;
        int castedInt = (int) originalDouble;
        System.out.println("Original double: " + originalDouble);
        System.out.println("After casting to int: " + castedInt);

        int originalInt = 25;
        double castedDouble = (double) originalInt;
        System.out.println("Original int: " + originalInt);
        System.out.println("After casting to double: " + castedDouble);
    }
}
