public class intefaceimplementation {
    // Interface Playable
    interface Playable {
        void play();
    }

    // Guitar class implementing Playable
    static class Guitar implements Playable {
        @Override
        public void play() {
            System.out.println("Playing guitar: Strumming strings... 🎸");
        }
    }

    // Piano class implementing Playable
    static class Piano implements Playable {
        @Override
        public void play() {
            System.out.println("Playing piano: Pressing keys... 🎹");
        }
    }

    public static void main(String[] args) {
        // Create Guitar object
        Playable guitar = new Guitar();
        System.out.println("Guitar:");
        guitar.play();
        System.out.println();

        // Create Piano object
        Playable piano = new Piano();
        System.out.println("Piano:");
        piano.play();
        System.out.println();

        // Demonstrate polymorphism with interface references
        Playable[] instruments = { new Guitar(), new Piano() };
        System.out.println("Playing all instruments:");
        for (Playable instrument : instruments) {
            instrument.play();
        }
    }
}
