public class task17 {
    // Car class
    static class Car {
        String make;
        String model;
        int year;

        // Constructor
        Car(String make, String model, int year) {
            this.make = make;
            this.model = model;
            this.year = year;
        }

        // Method to display car details
        void displayDetails() {
            System.out.println("Car Details:");
            System.out.println("Make: " + make);
            System.out.println("Model: " + model);
            System.out.println("Year: " + year);
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Create Car objects
        Car car1 = new Car("Toyota", "Camry", 2022);
        Car car2 = new Car("Honda", "Civic", 2023);
        Car car3 = new Car("BMW", "X5", 2021);

        // Display details of each car
        car1.displayDetails();
        car2.displayDetails();
        car3.displayDetails();
    }
}
